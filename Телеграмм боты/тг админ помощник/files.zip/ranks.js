import { tg } from './telegram.js';

export const RANK_NAMES = [
  'Участник',
  'Младший модератор',
  'Старший модератор',
  'Младший администратор',
  'Старший администратор',
  'Создатель',
];
export const rankLabel = (r) => `${r} ранг (${RANK_NAMES[r]})`;

const now = () => Math.floor(Date.now() / 1000);

// Ранг пользователя в чате. Нет записи в БД = 0.
// Владелец чата в Telegram автоматически получает 5 ранг.
export async function getRank(env, chatId, userId) {
  const row = await env.DB.prepare('SELECT rank FROM ranks WHERE chat_id = ? AND user_id = ?')
    .bind(chatId, userId)
    .first();
  if (row) return row.rank;

  const member = await tg(env, 'getChatMember', { chat_id: chatId, user_id: userId });
  if (member?.status === 'creator') {
    await env.DB.prepare(
      'INSERT OR IGNORE INTO ranks (chat_id, user_id, rank, assigned_by, updated_at) VALUES (?, ?, 5, NULL, ?)',
    )
      .bind(chatId, userId, now())
      .run();
    return 5;
  }
  return 0;
}

// Какой ранг получится после команды: { rank } или { error }
export function nextRank(cmd, current) {
  if (cmd.action === 'set') {
    if (cmd.strictUp && cmd.rank <= current) {
      return { error: `У пользователя уже ${current} ранг — «Повысить ${cmd.rank}» ничего не изменит.` };
    }
    return { rank: cmd.rank };
  }
  if (cmd.action === 'up') return { rank: current + 1 };
  if (current === 0) return { error: 'У пользователя нет ранга — понижать нечего.' };
  return { rank: current - 1 };
}

// Правила доступа. Возвращает текст отказа или null, если можно.
// ПРАВИЛА — в одном месте, чтобы их было легко поменять.
export function checkChange(issuer, current, next) {
  if (issuer < 2) return 'Недостаточно прав: ранги выдают начиная со 2 ранга.';
  if (current === 5) return 'Ранг создателя нельзя изменить этой командой.';
  if (next === current) return 'У пользователя уже такой ранг.';
  if (issuer < 5 && (current >= issuer || next >= issuer)) {
    return 'Можно управлять только рангами ниже вашего.';
  }
  return null;
}

export async function setRank(env, chatId, userId, oldRank, newRank, byUserId) {
  const t = now();
  const write =
    newRank === 0
      ? env.DB.prepare('DELETE FROM ranks WHERE chat_id = ? AND user_id = ?').bind(chatId, userId)
      : env.DB.prepare(
          `INSERT INTO ranks (chat_id, user_id, rank, assigned_by, updated_at) VALUES (?1, ?2, ?3, ?4, ?5)
           ON CONFLICT(chat_id, user_id) DO UPDATE SET rank = ?3, assigned_by = ?4, updated_at = ?5`,
        ).bind(chatId, userId, newRank, byUserId, t);
  const log = env.DB.prepare(
    'INSERT INTO rank_log (chat_id, user_id, old_rank, new_rank, by_user_id, created_at) VALUES (?, ?, ?, ?, ?, ?)',
  ).bind(chatId, userId, oldRank, newRank, byUserId, t);
  await env.DB.batch([write, log]);
}
