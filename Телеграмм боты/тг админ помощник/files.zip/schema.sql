-- Пользователи, которых бот видел в чатах (нужны, чтобы по @username найти id)
CREATE TABLE IF NOT EXISTS users (
  user_id    INTEGER PRIMARY KEY,
  username   TEXT,
  first_name TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

-- Ранги модераторов по чатам (нет строки = 0 ранг)
CREATE TABLE IF NOT EXISTS ranks (
  chat_id     INTEGER NOT NULL,
  user_id     INTEGER NOT NULL,
  rank        INTEGER NOT NULL CHECK (rank BETWEEN 1 AND 5),
  assigned_by INTEGER,
  updated_at  INTEGER NOT NULL,
  PRIMARY KEY (chat_id, user_id)
);

-- История изменений рангов (пригодится для команды «Лог изменений рангов»)
CREATE TABLE IF NOT EXISTS rank_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id    INTEGER NOT NULL,
  user_id    INTEGER NOT NULL,
  old_rank   INTEGER NOT NULL,
  new_rank   INTEGER NOT NULL,
  by_user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rank_log_chat ON rank_log(chat_id, id);
