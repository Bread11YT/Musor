# Бот для чатов (Telegram + Cloudflare Workers + D1)

Сейчас умеет: назначение рангов модераторов (0–5) — `+Модер N`, `!модер`, `!!модер`…, `Повысить [N]`, `Понизить`.

## Запуск

1. **Бот.** В @BotFather: `/newbot` → получите токен. Затем `/setprivacy` → *Disable*
   (иначе бот не видит обычные сообщения в группах). Добавьте бота в чат и сделайте админом.
2. **Проект.** `npm install`
3. **База.**
   `npx wrangler d1 create chat-bot` — скопируйте `database_id` в `wrangler.toml`, затем
   `npx wrangler d1 execute chat-bot --remote --file=schema.sql`
4. **Секреты.**
   `npx wrangler secret put BOT_TOKEN` — токен от BotFather
   `npx wrangler secret put WEBHOOK_SECRET` — любая строка из латиницы, цифр, `_` и `-`
5. **Деплой.** `npx wrangler deploy` — в конце покажет адрес `https://chat-bot.<аккаунт>.workers.dev`
6. **Webhook** (один раз, в браузере или curl):
   `https://api.telegram.org/bot<ТОКЕН>/setWebhook?url=<АДРЕС_ВОРКЕРА>&secret_token=<WEBHOOK_SECRET>&allowed_updates=["message"]`

Владелец чата в Telegram автоматически получает 5 ранг при первой команде.

## Файлы

- `parser.js` — разбор команд (чистые функции, легко тестировать)
- `ranks.js` — ранги, правила доступа (`checkChange`), запись в БД
- `telegram.js` — вызовы Telegram API, поиск цели команды
- `index.js` — вход webhook и маршрутизация
- `schema.sql` — таблицы D1
