// Разбор команд назначения ранга. Чистые функции: без сети и без БД.
// Все варианты записи сводятся к одному виду:
//   { action: 'set' | 'up' | 'down', rank?: 1..5, targetText: string }
//   set  — выставить ранг:  +Модер 3 · !модер 2 · !!!модер · Повысить 3
//   up   — «Повысить» без числа: +1 ранг
//   down — «Понизить»: −1 ранг

const WORD = '(?:модер|админ)';
const RE_BANGS = new RegExp(`^(!{2,4})${WORD}(?:\\s+(.+))?$`, 'iu'); // !!модер … !!!!модер
const RE_PLUS = new RegExp(`^[+!]${WORD}(?:\\s+([1-5])(?=\\s|$))?(?:\\s+(.+))?$`, 'iu'); // +Модер 3, !модер
const RE_UP = /^повысить(?:\s+([1-5])(?=\s|$))?(?:\s+(.+))?$/iu;
const RE_DOWN = /^понизить(?:\s+(.+))?$/iu;

export function parseRankCommand(text) {
  const t = text.trim();
  let m;
  if ((m = RE_BANGS.exec(t))) return { action: 'set', rank: m[1].length, targetText: m[2] ?? '' };
  if ((m = RE_PLUS.exec(t))) return { action: 'set', rank: m[1] ? Number(m[1]) : 1, targetText: m[2] ?? '' };
  if ((m = RE_UP.exec(t))) {
    return m[1]
      ? { action: 'set', rank: Number(m[1]), strictUp: true, targetText: m[2] ?? '' } // «Повысить 3» — только вверх
      : { action: 'up', targetText: m[2] ?? '' };
  }
  if ((m = RE_DOWN.exec(t))) return { action: 'down', targetText: m[1] ?? '' };
  return null;
}

// Ссылка на пользователя: @username, t.me/username, tg://user?id=…, числовой id
export function parseRef(token) {
  let m;
  if ((m = /^@([A-Za-z0-9_]{4,32})$/.exec(token))) return { username: m[1] };
  if ((m = /^(?:https?:\/\/)?t\.me\/([A-Za-z0-9_]{4,32})\/?$/i.exec(token))) return { username: m[1] };
  if ((m = /^tg:\/\/user\?id=(\d+)$/i.exec(token))) return { id: Number(m[1]) };
  if (/^\d{5,15}$/.test(token)) return { id: Number(token) };
  return null;
}
