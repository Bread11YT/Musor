import { parseRef } from './parser.js';

export async function tg(env, method, params = {}) {
  const res = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!data.ok) console.error(method, data.description);
  return data.ok ? data.result : null;
}

export const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const nameOf = (u) => u.first_name || (u.username ? '@' + u.username : String(u.id));
export const mention = (u) => `<a href="tg://user?id=${u.id}">${esc(nameOf(u))}</a>`;

export const reply = (env, msg, html) =>
  tg(env, 'sendMessage', {
    chat_id: msg.chat.id,
    text: html,
    parse_mode: 'HTML',
    reply_parameters: { message_id: msg.message_id, allow_sending_without_reply: true },
    link_preview_options: { is_disabled: true },
  });

// Запоминаем людей, которых видим в чате: Telegram не умеет находить пользователя
// по @username, поэтому ведём свою таблицу. Пишем в БД только если что-то изменилось.
export async function rememberUsers(env, msg) {
  const all = [
    msg.from,
    msg.reply_to_message?.from,
    ...(msg.new_chat_members ?? []),
    ...(msg.entities ?? []).filter((e) => e.type === 'text_mention').map((e) => e.user),
  ].filter((u) => u && !u.is_bot);
  const unique = [...new Map(all.map((u) => [u.id, u])).values()];
  if (!unique.length) return;

  const t = Math.floor(Date.now() / 1000);
  await env.DB.batch(
    unique.map((u) =>
      env.DB.prepare(
        `INSERT INTO users (user_id, username, first_name, updated_at) VALUES (?1, ?2, ?3, ?4)
         ON CONFLICT(user_id) DO UPDATE SET username = ?2, first_name = ?3, updated_at = ?4
         WHERE users.username IS NOT ?2 OR users.first_name IS NOT ?3 OR users.updated_at < ?4 - 86400`,
      ).bind(u.id, u.username?.toLowerCase() ?? null, u.first_name ?? '', t),
    ),
  );
}

// Кто цель команды. Приоритет: упоминание по имени → ссылка/@username/id в тексте → ответ на сообщение.
// Возвращает { user } | { error: 'missing' | 'unknown' } | null (null = это не команда к человеку, игнорируем).
export async function resolveTarget(env, msg, targetText) {
  const mentioned = (msg.entities ?? []).find((e) => e.type === 'text_mention' && e.user);
  if (mentioned) return { user: mentioned.user };

  const token = targetText.split(/\s+/)[0];
  if (token) {
    const ref = parseRef(token);
    if (!ref) return null; // например «повысить зарплату» — обычная речь
    const row = ref.id
      ? await env.DB.prepare('SELECT user_id AS id, username, first_name FROM users WHERE user_id = ?').bind(ref.id).first()
      : await env.DB.prepare(
          'SELECT user_id AS id, username, first_name FROM users WHERE username = ? ORDER BY updated_at DESC LIMIT 1',
        )
          .bind(ref.username.toLowerCase())
          .first();
    if (row) return { user: row };
    return ref.id ? { user: { id: ref.id } } : { error: 'unknown' };
  }

  const replied = msg.reply_to_message?.from;
  return replied ? { user: replied } : { error: 'missing' };
}
