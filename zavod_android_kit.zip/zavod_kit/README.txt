Набор файлов для Android Studio — «Бесконечный завод»
Структура повторяет папку app/src/main/ нового проекта:

  app/src/main/AndroidManifest.xml
  app/src/main/java/com/example/zavod/MainActivity.kt
  app/src/main/assets/index.html      <- сама игра

Название пакета в проекте ДОЛЖНО быть com.example.zavod.
Подробная инструкция — в чате.
