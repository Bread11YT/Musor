# Tower Defense (Forge 1.20.1)

1. Скачай Forge MDK 1.20.1 (47.x) и распакуй.
2. Скопируй папку `src/` из этого архива в MDK с заменой (удали примерный пакет из MDK).
3. В `gradle.properties` MDK: `mod_id=towerdefense`, `mod_group_id=com.example.towerdefense`.
4. JDK 17, затем `gradlew genIntellijRuns` и запуск `runClient`.
